WP Pond 0.1.0 - Windows 64-bit (desktop app)

REQUIREMENTS
  Windows 10 or 11, 64-bit. The Microsoft Edge WebView2 runtime is
  required; the installer fetches it automatically, and this portable archive
  expects it to be present (Windows 11 ships it, and most Windows 10 machines
  already have it through Edge).

CONTENTS
  wppond-app.exe      the WP Pond desktop app
  wppond-helper.exe   privileged helper (hosts file, CA trust, port grant)

GETTING STARTED
  Unzip both files into the same folder and run wppond-app.exe.

  Keep wppond-helper.exe next to wppond-app.exe. Actions that need
  administrator rights are brokered through it, and Windows will prompt you.

  PHP, MariaDB/MySQL, nginx and WP-CLI are downloaded on demand the first
  time a site needs them.
