WP Pond 0.1.0 - Windows 64-bit

REQUIREMENTS
  Windows 10 or 11, 64-bit. Nothing to install first: these binaries import
  only system DLLs, so no Visual C++ redistributable is needed.

CONTENTS
  wppond.exe          the command line interface
  wppond-helper.exe   privileged helper (hosts file, CA trust, port grant)

GETTING STARTED
  Unzip both files into the same folder, open a terminal there, and run:

    wppond.exe info      show resolved paths and configuration
    wppond.exe create    create a WordPress site

  Keep wppond-helper.exe next to wppond.exe. Actions that need administrator
  rights (editing the hosts file, trusting the local CA, granting the
  privileged port) are brokered through it, and Windows will prompt you.

  PHP, MariaDB/MySQL, nginx and WP-CLI are downloaded on demand the first
  time a site needs them.

NOTE
  This is an early build. The desktop GUI is not included in this archive.
